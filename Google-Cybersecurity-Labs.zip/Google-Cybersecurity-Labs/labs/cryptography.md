# Cryptography & Security Fundamentals Labs

**Google Cybersecurity Professional Certificate**

All labs below were provided as completed at **100%**.

| Lab | Completed |
|---|---|
| [Create hash values](https://www.skills.google/focuses/132482?parent=catalog) | Apr 22, 2026 |
| [Decrypt an encrypted message](https://www.skills.google/focuses/132486?parent=catalog) | Apr 22, 2026 |

## Skills represented

- Cryptographic hashing
- Encryption/decryption concepts
- Security fundamentals
