# SQL & Security Data Analysis Labs

**Google Cybersecurity Professional Certificate**

All labs below were provided as completed at **100%**.

| Lab | Completed |
|---|---|
| [Perform a SQL query](https://www.skills.google/focuses/132499?parent=catalog) | Apr 5, 2026 |
| [Filter a SQL query](https://www.skills.google/focuses/132490?parent=catalog) | Apr 5–6, 2026 |
| [Apply more filters in SQL](https://www.skills.google/focuses/132476?parent=catalog) | Apr 7, 2026 |
| [Filter with AND, OR, and NOT](https://www.skills.google/focuses/132491?parent=catalog) | Apr 8, 2026 |
| [Complete a SQL join](https://www.skills.google/focuses/132479?parent=catalog) | Apr 8, 2026 |

## Skills represented

- SQL querying
- Filtering
- Logical operators
- JOIN operations
- Security-oriented data analysis
