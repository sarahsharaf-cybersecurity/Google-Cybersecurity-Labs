# Network Security & Packet Analysis Labs

**Google Cybersecurity Professional Certificate**

All labs below were provided as completed at **100%**.

| Lab | Completed |
|---|---|
| [Analyze your first packet with Wireshark](https://www.skills.google/focuses/132475?parent=catalog) | Jun 7, 2026 |
| [Capture your first packet](https://www.skills.google/focuses/132478?parent=catalog) | Jun 24, 2026 |

## Skills represented

- Packet capture
- Wireshark
- Network traffic analysis
- TCP/IP fundamentals
- Network investigation
