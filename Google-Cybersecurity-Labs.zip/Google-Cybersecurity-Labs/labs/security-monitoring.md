# Security Monitoring & IDS Labs

**Google Cybersecurity Professional Certificate**

All labs below were provided as completed at **100%**.

| Lab | Completed |
|---|---|
| [Examine alerts, logs, and rules with Suricata](https://www.skills.google/focuses/132488?parent=catalog) | Jun 30, 2026 |

## Skills represented

- Suricata
- IDS concepts
- Security alerts
- Security logs
- Detection rules
- Security event analysis

## Related Portfolio Work

The separate **Phishing Alert Investigation & SOC Escalation** project demonstrates alert triage, phishing analysis, malicious-file identification, and escalation to a Level 2 SOC analyst.
