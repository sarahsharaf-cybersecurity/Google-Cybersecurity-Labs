# Linux & Command Line Labs

**Google Cybersecurity Professional Certificate**

All labs below were provided as completed at **100%**.

| Lab | Completed |
|---|---|
| [Examine input/output in the Linux shell](https://www.skills.google/focuses/132489?parent=catalog) | Mar 24, 2026 |
| [Install software in a Linux distribution](https://www.skills.google/focuses/132496?parent=catalog) | Mar 24, 2026 |
| [Find files with Linux commands](https://www.skills.google/focuses/132493?parent=catalog) | Apr 1, 2026 |
| [Filter with grep](https://www.skills.google/focuses/132492?parent=catalog) | Apr 3, 2026 |
| [Manage files with Linux commands](https://www.skills.google/focuses/132498?parent=catalog) | Apr 4, 2026 |
| [Manage authorization](https://www.skills.google/focuses/132497?parent=catalog) | Apr 4, 2026 |
| [Add and manage users with Linux commands](https://www.skills.google/focuses/132474?parent=catalog) | Apr 4, 2026 |
| [Get help in the command line](https://www.skills.google/focuses/132494?parent=catalog) | Apr 5, 2026 |

## Skills represented

- Linux command-line workflows
- Shell input/output
- File and directory management
- File searching and filtering
- `grep`
- User management
- Authorization and permissions
- Software installation
- Command-line help and troubleshooting
